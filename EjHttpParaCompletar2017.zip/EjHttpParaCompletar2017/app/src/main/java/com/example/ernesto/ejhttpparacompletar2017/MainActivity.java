package com.example.ernesto.ejhttpparacompletar2017;

import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

public class MainActivity extends AppCompatActivity implements Handler.Callback {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // flag en true para recibir bytes
        ThreadConexion tc = new ThreadConexion("http://www.lslutnfra.com/alumnos/practicas/ubuntu-logo.png",true);
        Thread t = new Thread(tc);
        t.start();
        //________________________________

        // flag en false para recibir un string
        ThreadConexion tc2 = new ThreadConexion("http://www.lslutnfra.com/alumnos/practicas/listaPersonas.xml",false);
        Thread t2 = new Thread(tc2);
        t2.start();
        //_____________________________________

    }

    @Override
    public boolean handleMessage(Message msg) {

        switch(msg.arg1)
        {
            case 0:{
                Log.d("activity", "Error");
                break;
            }
            case 1:{
                Log.d("activity","Recibiendo bytes (imagen)");
                // Cargar imagen en imageview
                break;
            }
            case 2:{
                Log.d("activity","Recibiendo string (json)");
                // cargar texto en textView
                break;
            }
        }
        return true;
    }
}
